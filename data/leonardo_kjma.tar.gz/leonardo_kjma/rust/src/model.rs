//! Model parameters and the Hamiltonian H = H_I + h Sᶻ_tot as a real combination of Pauli strings.
//!
//! H_I = Σ_j [ Σ_α ( a_α R_{j,j+1} σ^α_{j+2} + b_α σ^α_{j−1} R_{j,j+1} )
//!           + Σ_{αβ} c_{αβ} σ^β_{j−1} R_{j,j+1} σ^α_{j+2} ],
//! with the singlet projector R_{j,j+1} = (1 − σ_j·σ_{j+1}) / 4.

use std::collections::BTreeMap;
use std::fs::{self, File};
use std::io::{BufWriter, Write};
use std::path::Path;

use crate::parameters;
use crate::pauli::Pauli;
use crate::trajectory::Rng;

#[derive(Clone, Debug)]
pub struct Params {
    pub l: usize,
    /// Lifting field: H|Φ_n⟩ = h (L/2 − n)|Φ_n⟩.
    pub h: f64,
    /// a[α] multiplies R_{j,j+1} σ^α_{j+2}.
    pub a: [f64; 3],
    /// b[α] multiplies σ^α_{j−1} R_{j,j+1}.
    pub b: [f64; 3],
    /// c[α][β] multiplies σ^β_{j−1} R_{j,j+1} σ^α_{j+2}.
    pub c: [[f64; 3]; 3],
    /// Site-dependent c: if set, c_bond[j] replaces c in the term on bond (j, j+1). Breaks translation.
    pub c_bond: Option<Vec<[[f64; 3]; 3]>>,
    /// Periodic ring (needs L ≥ 4). Open chain: a term is kept only if all its sites exist.
    pub periodic: bool,
}

impl Params {
    /// Uniform couplings from `parameters.rs` (the current coefficients of CLAUDE.md).
    pub fn baseline(l: usize) -> Self {
        Params {
            l,
            h: parameters::H,
            a: parameters::A,
            b: parameters::B,
            c: parameters::C,
            c_bond: None,
            periodic: parameters::PERIODIC,
        }
    }

    /// Baseline with random c: on every bond, each c[α][β] is multiplied by an independent factor
    /// uniform in `parameters::C_RANDOM_RANGE` (default [0.5, 1.5]; signs kept, zero entries stay zero).
    /// One uniform number is drawn per entry and bond, zero or not, so a realization depends only on
    /// the seed and L.
    pub fn random_c(l: usize, rng: &mut Rng) -> Self {
        let base = Self::baseline(l);
        let (low, high) = parameters::C_RANDOM_RANGE;
        let c_bond = (0..l).map(|_| base.c.map(|row| row.map(|c| c * (low + (high - low) * rng.uniform())))).collect();
        Params { c_bond: Some(c_bond), ..base }
    }

    pub fn translation_invariant(&self) -> bool {
        self.periodic && self.c_bond.is_none()
    }

    /// H_I = 0: independent spins in the field h (exact reference 2).
    pub fn free_spins(l: usize) -> Self {
        Params { a: [0.0; 3], b: [0.0; 3], c: [[0.0; 3]; 3], c_bond: None, ..Self::baseline(l) }
    }
}

/// H = Σ_a coef_a P_a with real coefficients; identical strings are merged, the identity is dropped.
pub fn hamiltonian_terms(p: &Params) -> Vec<(Pauli, f64)> {
    let mut terms: BTreeMap<Pauli, f64> = BTreeMap::new();
    for j in 0..p.l {
        for (string, coef) in bond_terms(p, j) {
            *terms.entry(string).or_insert(0.0) += coef;
        }
    }
    for j in 0..p.l {
        *terms.entry(Pauli::single(2, j)).or_insert(0.0) += p.h / 2.0;
    }
    terms.remove(&Pauli::IDENTITY);
    terms.into_iter().filter(|&(_, coef)| coef != 0.0).collect()
}

/// The term of H_I on bond (j, j+1) (sites j − 1 … j + 2), Σ_α (a_α R σ^α_{j+2} + b_α σ^α_{j−1} R) + Σ c σ R σ,
/// as Pauli strings, not merged: on a ring of L ≥ 4 the strings of one bond are all different. It annihilates
/// the tower on its own. Empty if the bond does not exist (open chain); a dressing whose site does not exist is
/// dropped. H_I is the sum over j = 0 … L − 1.
pub fn bond_terms(p: &Params, j: usize) -> Vec<(Pauli, f64)> {
    let l = p.l as isize;
    assert!(p.l <= 32);
    assert!(!p.periodic || p.l >= 4, "periodic boundaries need L >= 4");
    let site = |j: isize| -> Option<usize> {
        if p.periodic {
            Some(j.rem_euclid(l) as usize)
        } else {
            (0..l).contains(&j).then_some(j as usize)
        }
    };

    let j = j as isize;
    let mut terms = Vec::new();
    let (Some(s1), Some(s2)) = (site(j), site(j + 1)) else { return terms };
    // coef · R_{s1,s2} · dressing = (coef / 4) (dressing − Σ_δ σ^δ_{s1} σ^δ_{s2} dressing)
    let mut add_dressed = |coef: f64, dressing: Pauli| {
        if coef == 0.0 {
            return;
        }
        terms.push((dressing, coef / 4.0));
        for delta in 0..3 {
            let bond = Pauli::single(delta, s1).times_disjoint(Pauli::single(delta, s2));
            terms.push((bond.times_disjoint(dressing), -(coef / 4.0)));
        }
    };
    let (left, right) = (site(j - 1), site(j + 2));
    let c = p.c_bond.as_ref().map_or(&p.c, |c_bond| &c_bond[j as usize]);
    for alpha in 0..3 {
        if let Some(r) = right {
            add_dressed(p.a[alpha], Pauli::single(alpha, r));
        }
        if let Some(lf) = left {
            add_dressed(p.b[alpha], Pauli::single(alpha, lf));
        }
        if let (Some(lf), Some(r)) = (left, right) {
            for beta in 0..3 {
                add_dressed(c[alpha][beta], Pauli::single(beta, lf).times_disjoint(Pauli::single(alpha, r)));
            }
        }
    }
    terms
}

/// `_seed<N>` for a realization seed other than 1, empty for seed 1 (the files of the first realization keep their
/// names). Added to every output file name of `states`, `states_traj` and `single_flip`.
pub fn seed_suffix(seed: u64) -> String {
    if seed == 1 {
        String::new()
    } else {
        format!("_seed{seed}")
    }
}

/// Writes `states_realization_L<L>[_seed<N>].csv` in `data`: the c coefficients of bond (j, j+1), one row per bond
/// (only the entries nonzero in parameters.rs).
pub fn write_realization(data: &Path, params: &Params, seed: u64) {
    let c_bond = params.c_bond.as_ref().unwrap();
    let axes = ["x", "y", "z"];
    let entries: Vec<(usize, usize)> =
        (0..3).flat_map(|a| (0..3).map(move |b| (a, b))).filter(|&(a, b)| params.c[a][b] != 0.0).collect();
    // several jobs can write the same file at once: write a private copy and rename it (atomic)
    let file = data.join(format!("states_realization_L{}{}.csv", params.l, seed_suffix(seed)));
    let tmp = data.join(format!("states_realization_L{}{}.csv.{}", params.l, seed_suffix(seed), std::process::id()));
    let mut csv = BufWriter::new(File::create(&tmp).unwrap());
    let names: Vec<String> = entries.iter().map(|&(a, b)| format!("c_{}{}", axes[a], axes[b])).collect();
    writeln!(csv, "j,{}", names.join(",")).unwrap();
    for (j, c) in c_bond.iter().enumerate() {
        let c: Vec<String> = entries.iter().map(|&(a, b)| format!("{:.12}", c[a][b])).collect();
        writeln!(csv, "{j},{}", c.join(",")).unwrap();
    }
    csv.into_inner().unwrap().sync_all().unwrap();
    fs::rename(&tmp, &file).unwrap();
}
