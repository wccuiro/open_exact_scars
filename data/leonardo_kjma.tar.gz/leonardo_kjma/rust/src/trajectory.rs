//! Pure-state trajectories for the dephasing Lindbladian.
//!
//! The jump operators √γ σᶻ_j are Hermitian, so the Lindblad equation can be unravelled as a
//! diffusion driven by real white noise that keeps the state normalized: every spin feels a
//! fluctuating z field,
//!
//!   d|ψ⟩ = −iH|ψ⟩ dt − i√γ Σ_j σᶻ_j |ψ⟩ dW_j − (γL/2)|ψ⟩ dt        (Itô, ⟨dW_j dW_k⟩ = δ_jk dt),
//!
//! and the average of |ψ⟩⟨ψ| over the noise obeys dρ/dt = −i[H, ρ] + γ Σ_j (σᶻ_j ρ σᶻ_j − ρ).
//! One time step is  e^{−iH dt/2} · Π_j e^{−i√γ ΔW_j σᶻ_j} · e^{−iH dt/2}  with ΔW_j ~ N(0, dt):
//! the noise factor averages to the exact dephasing channel over dt, and the symmetric splitting
//! leaves an error O(dt²) in the averaged dynamics.
//!
//! Jump unravelling (`JumpTrajectory`): since (σᶻ_j)² = 1 the effective Hamiltonian is H − iγL/2, a constant
//! shift, so a trajectory is unitary evolution under H interrupted by σᶻ_j kicks. The waiting times are
//! exponential with total rate γL and the kicked site is uniform, independently of the state, so the
//! sampling is exact; the only error is that of e^{−iHτ} (Taylor series summed to round-off).
//!
//! States are vectors of 2^L amplitudes over bit strings, bit j = 0 for |↑⟩ and 1 for |↓⟩.

use rayon::prelude::*;

use crate::model::{hamiltonian_terms, Params};
use crate::noise::Channel;

/// H psi is split over threads from this many amplitudes per chunk (only for large states).
const APPLY_CHUNK: usize = 1 << 14;
/// Taylor substeps of e^{−iH τ} have 1.5 · (estimated ‖H‖) · τ ≤ SUBSTEP_NORM (as in `liouville.rs`).
const SUBSTEP_NORM: f64 = 4.0;

/// Complex amplitude [re, im].
pub type Amp = [f64; 2];

struct Term {
    z: usize,
    coef: Amp,
}

/// H as a sum of Pauli strings acting on state vectors, grouped by flip mask x: (H ψ)(t) =
/// Σ_x [Σ_{terms of x} coef (−1)^{|z & s|}] ψ(s), s = t ^ x, so ψ(s) is read once per group.
pub struct Hamiltonian {
    pub l: usize,
    /// (x, range of `terms` with that x)
    groups: Vec<(usize, std::ops::Range<usize>)>,
    terms: Vec<Term>,
    /// Estimate of the spectral radius of H, used to size the Taylor steps.
    norm: f64,
}

impl Hamiltonian {
    pub fn new(params: &Params) -> Self {
        // P|s⟩ = i^{n_y} (−1)^{|z & s|} |s ^ x⟩: fold i^{n_y} into the coefficient
        let mut by_x: Vec<(usize, Term)> = hamiltonian_terms(params)
            .into_iter()
            .map(|(p, h)| {
                let coef = [[h, 0.0], [0.0, h], [-h, 0.0], [0.0, -h]][(p.n_y() % 4) as usize];
                (p.x as usize, Term { z: p.z as usize, coef })
            })
            .collect();
        by_x.sort_by_key(|&(x, _)| x);
        let mut groups: Vec<(usize, std::ops::Range<usize>)> = Vec::new();
        for (k, &(x, _)) in by_x.iter().enumerate() {
            match groups.last_mut() {
                Some((gx, range)) if *gx == x => range.end = k + 1,
                _ => groups.push((x, k..k + 1)),
            }
        }
        let terms = by_x.into_iter().map(|(_, term)| term).collect();
        let mut ham = Hamiltonian { l: params.l, groups, terms, norm: 0.0 };

        // power iteration from a fixed pseudo-random vector
        let dim = 1usize << params.l;
        let mut rng = Rng::new(0x5eed);
        let mut v: Vec<Amp> = (0..dim).map(|_| [rng.gaussian(), rng.gaussian()]).collect();
        let mut w = vec![[0.0; 2]; dim];
        for _ in 0..40 {
            let scale = 1.0 / norm_sqr(&v).sqrt();
            v.iter_mut().for_each(|a| *a = [a[0] * scale, a[1] * scale]);
            ham.apply(&v, &mut w);
            ham.norm = norm_sqr(&w).sqrt();
            std::mem::swap(&mut v, &mut w);
        }
        ham
    }

    /// out = H psi. Large states are split over threads (nested inside the parallel trajectories,
    /// rayon balances the two levels).
    pub fn apply(&self, psi: &[Amp], out: &mut [Amp]) {
        if out.len() >= 2 * APPLY_CHUNK {
            out.par_chunks_mut(APPLY_CHUNK)
                .enumerate()
                .for_each(|(c, chunk)| self.apply_rows(psi, chunk, c * APPLY_CHUNK));
        } else {
            self.apply_rows(psi, out, 0);
        }
    }

    /// out[i] = (H psi)[offset + i].
    fn apply_rows(&self, psi: &[Amp], out: &mut [Amp], offset: usize) {
        for (i, o) in out.iter_mut().enumerate() {
            let t = offset + i;
            let (mut re, mut im) = (0.0, 0.0);
            for (x, range) in &self.groups {
                let s = t ^ x;
                let (mut cr, mut ci) = (0.0, 0.0);
                for term in &self.terms[range.clone()] {
                    if (term.z & s).count_ones() & 1 == 0 {
                        cr += term.coef[0];
                        ci += term.coef[1];
                    } else {
                        cr -= term.coef[0];
                        ci -= term.coef[1];
                    }
                }
                let [pr, pi] = psi[s];
                re += cr * pr - ci * pi;
                im += cr * pi + ci * pr;
            }
            *o = [re, im];
        }
    }
}

fn norm_sqr(v: &[Amp]) -> f64 {
    v.iter().map(|a| a[0] * a[0] + a[1] * a[1]).sum()
}

/// One trajectory: the state and the workspace of the Taylor series.
pub struct Trajectory<'a> {
    ham: &'a Hamiltonian,
    pub psi: Vec<Amp>,
    term: Vec<Amp>,
    tmp: Vec<Amp>,
    rng: Rng,
    /// Hermitian jump operators of the diffusive unravelling, (axis 0, 1, 2 = x, y, z; rate per unit of γ):
    /// σᶻ dephasing by default (noise::Channel::hermitian_jumps for the others).
    jumps: Vec<(usize, f64)>,
    /// Some(rate): instead of `jumps`, one isotropic rotation exp[−i √(rate γ) Σ_α ΔW_α σ^α] per site and step
    /// (three independent ΔW_α ~ N(0, dt)); the depolarizing channel `--noise depol` (rate 1/3).
    isotropic: Option<f64>,
}

impl<'a> Trajectory<'a> {
    /// Starts in |−⟩^⊗L. Different seeds give independent noise.
    pub fn new(ham: &'a Hamiltonian, seed: u64) -> Self {
        let dim = 1usize << ham.l;
        let amp = 0.5f64.powf(ham.l as f64 / 2.0);
        let psi = (0..dim).map(|s| [if s.count_ones() % 2 == 0 { amp } else { -amp }, 0.0]).collect();
        Trajectory {
            ham,
            psi,
            term: vec![[0.0; 2]; dim],
            tmp: vec![[0.0; 2]; dim],
            rng: Rng::new(seed),
            jumps: vec![(2, 1.0)],
            isotropic: None,
        }
    }

    /// Other Hermitian jump operators for the diffusive unravelling (see `jumps`).
    pub fn with_jumps(mut self, jumps: Vec<(usize, f64)>) -> Self {
        self.jumps = jumps;
        self
    }

    /// The diffusive unravelling of a Hermitian noise channel: one isotropic rotation per site and step for
    /// `Channel::Depol`, one rotation per jump axis otherwise.
    pub fn with_channel(mut self, channel: &Channel) -> Self {
        self.isotropic = channel.isotropic_rate();
        self.jumps = channel.hermitian_jumps().expect("diffusive unravelling: Hermitian jump operators only");
        self
    }

    /// One isotropic rotation exp[−i √(rate γ) Σ_α ΔW_α σ^α] per site and step instead of the per-axis jumps.
    pub fn with_isotropic(mut self, rate: f64) -> Self {
        self.isotropic = Some(rate);
        self
    }

    /// Starts in the given normalized state vector (2^L amplitudes).
    pub fn from_state(ham: &'a Hamiltonian, psi: Vec<Amp>, seed: u64) -> Self {
        assert_eq!(psi.len(), 1usize << ham.l);
        let mut traj = Self::new(ham, seed);
        traj.psi = psi;
        traj
    }

    /// Starts in the product state with spin j along the unit vector bloch[j]:
    /// cos(θ/2)|↑⟩ + e^{iφ} sin(θ/2)|↓⟩.
    pub fn product(ham: &'a Hamiltonian, bloch: &[[f64; 3]], seed: u64) -> Self {
        assert_eq!(bloch.len(), ham.l);
        Self::from_state(ham, product_amplitudes(bloch), seed)
    }

    /// psi ← e^{−iH tau} psi, Taylor series summed to round-off in substeps of norm ≤ SUBSTEP_NORM.
    pub fn unitary(&mut self, tau: f64) {
        let n_sub = (1.5 * self.ham.norm * tau / SUBSTEP_NORM).ceil().max(1.0) as usize;
        let tau = tau / n_sub as f64;
        for _ in 0..n_sub {
            self.term.copy_from_slice(&self.psi);
            for order in 1..=60 {
                self.ham.apply(&self.term, &mut self.tmp);
                // term ← (−i tau / order) H term
                let f = tau / order as f64;
                let mut size = 0.0;
                for ((t, h), p) in self.term.iter_mut().zip(&self.tmp).zip(self.psi.iter_mut()) {
                    *t = [h[1] * f, -h[0] * f];
                    p[0] += t[0];
                    p[1] += t[1];
                    size += t[0] * t[0] + t[1] * t[1];
                }
                if size <= 1e-34 {
                    break;
                }
                assert!(order < 60, "Taylor series did not converge");
            }
        }
    }

    /// psi ← Π_j Π_k e^{−iθ_jk σ^{α_k}_j} psi with θ_jk = √(rate_k γ) ΔW_jk, up to a global phase. Averaging
    /// e^{−iθσ^α} ρ e^{iθσ^α} over θ ~ N(0, rate γ dt) damps the coherences between the σ^α eigenstates by
    /// e^{−2 rate γ dt}, which is the Lindblad channel of √(rate γ) σ^α over dt.
    fn kick(&mut self, gamma: f64, dt: f64) {
        if let Some(rate) = self.isotropic {
            return self.kick_isotropic(rate * gamma * dt);
        }
        for j in 0..self.ham.l {
            let bit = 1usize << j;
            for k in 0..self.jumps.len() {
                let (axis, rate) = self.jumps[k];
                let theta = (rate * gamma * dt).sqrt() * self.rng.gaussian();
                match axis {
                    2 => {
                        // relative phase e^{2iθ} on |↓⟩_j
                        let (sin, cos) = (2.0 * theta).sin_cos();
                        for (s, a) in self.psi.iter_mut().enumerate() {
                            if s & bit != 0 {
                                *a = [a[0] * cos - a[1] * sin, a[0] * sin + a[1] * cos];
                            }
                        }
                    }
                    _ => {
                        // e^{−iθσˣ} = cos θ − i sin θ σˣ;  e^{−iθσʸ} = [[cos θ, −sin θ], [sin θ, cos θ]] on (|↑⟩, |↓⟩)
                        let (sin, cos) = theta.sin_cos();
                        for s in (0..self.psi.len()).filter(|s| s & bit == 0) {
                            let (up, down) = (self.psi[s], self.psi[s | bit]);
                            let (new_up, new_down) = if axis == 0 {
                                (
                                    [cos * up[0] + sin * down[1], cos * up[1] - sin * down[0]],
                                    [cos * down[0] + sin * up[1], cos * down[1] - sin * up[0]],
                                )
                            } else {
                                (
                                    [cos * up[0] - sin * down[0], cos * up[1] - sin * down[1]],
                                    [sin * up[0] + cos * down[0], sin * up[1] + cos * down[1]],
                                )
                            };
                            self.psi[s] = new_up;
                            self.psi[s | bit] = new_down;
                        }
                    }
                }
            }
        }
    }

    /// psi ← Π_j exp(−i θ_j·σ_j) psi with θ_jα = √variance · (independent standard normal): one rotation per site
    /// about a random axis. exp(−i θ·σ) = cos|θ| − i (sin|θ| / |θ|) θ·σ, and θ·σ = [[θ_z, θ_x − iθ_y], [θ_x + iθ_y,
    /// −θ_z]] on (|↑⟩, |↓⟩). Averaged over θ it shrinks every Bloch component by 1 − 4 var + (20/3) var² + …, the
    /// depolarizing channel e^{−4 var} to O(var²) = O(dt²) per step.
    fn kick_isotropic(&mut self, variance: f64) {
        let sd = variance.sqrt();
        for j in 0..self.ham.l {
            let bit = 1usize << j;
            let th = [0; 3].map(|_| sd * self.rng.gaussian());
            let norm = (th[0] * th[0] + th[1] * th[1] + th[2] * th[2]).sqrt();
            let (sin, cos) = norm.sin_cos();
            let f = if norm > 0.0 { sin / norm } else { 1.0 };
            let (ax, ay, az) = (f * th[0], f * th[1], f * th[2]);
            // u00 = cos − i az, u01 = −ay − i ax, u10 = ay − i ax, u11 = cos + i az
            let mul = |u: Amp, a: Amp| [u[0] * a[0] - u[1] * a[1], u[0] * a[1] + u[1] * a[0]];
            let (u00, u01, u10, u11) = ([cos, -az], [-ay, -ax], [ay, -ax], [cos, az]);
            for s in (0..self.psi.len()).filter(|s| s & bit == 0) {
                let (up, down) = (self.psi[s], self.psi[s | bit]);
                let (a, b) = (mul(u00, up), mul(u01, down));
                let (c, d) = (mul(u10, up), mul(u11, down));
                self.psi[s] = [a[0] + b[0], a[1] + b[1]];
                self.psi[s | bit] = [c[0] + d[0], c[1] + d[1]];
            }
        }
    }

    /// psi ← σᶻ_j psi.
    pub fn flip(&mut self, j: usize) {
        let bit = 1usize << j;
        for (s, a) in self.psi.iter_mut().enumerate() {
            if s & bit != 0 {
                *a = [-a[0], -a[1]];
            }
        }
    }

    /// Advance by dt.
    pub fn step(&mut self, gamma: f64, dt: f64) {
        self.unitary(dt / 2.0);
        if gamma > 0.0 {
            self.kick(gamma, dt);
        }
        self.unitary(dt / 2.0);
    }

    /// [m_x, m_y, m_z], m_α = (1/L) Σ_j ⟨ψ|σ^α_j|ψ⟩.
    pub fn magnetization(&self) -> [f64; 3] {
        let l = self.ham.l as f64;
        self.per_site().map(|m| m.iter().sum::<f64>() / l)
    }

    /// ⟨ψ|σ^α_j|ψ⟩ for α = x, y, z and every site j.
    pub fn per_site(&self) -> [Vec<f64>; 3] {
        per_site_expectations(&self.psi, self.ham.l)
    }
}

/// ⟨ψ|σ^α_j|ψ⟩ for α = x, y, z and every site j of a state vector of 2^l amplitudes.
pub fn per_site_expectations(psi: &[Amp], l: usize) -> [Vec<f64>; 3] {
    let mut m = [vec![0.0; l], vec![0.0; l], vec![0.0; l]];
    for j in 0..l {
        let bit = 1usize << j;
        for s in (0..psi.len()).filter(|s| s & bit == 0) {
            let (up, down) = (psi[s], psi[s | bit]);
            // conj(down) · up
            let (re, im) = (down[0] * up[0] + down[1] * up[1], down[0] * up[1] - down[1] * up[0]);
            m[0][j] += 2.0 * re;
            m[1][j] -= 2.0 * im;
            m[2][j] += up[0] * up[0] + up[1] * up[1] - down[0] * down[0] - down[1] * down[1];
        }
    }
    m
}

/// Amplitudes of the product state with spin j along the unit vector bloch[j]: cos(θ/2)|↑⟩ + e^{iφ} sin(θ/2)|↓⟩.
pub fn product_amplitudes(bloch: &[[f64; 3]]) -> Vec<Amp> {
    let spins: Vec<[Amp; 2]> = bloch
        .iter()
        .map(|&[x, y, z]| {
            let (up, down) = (((1.0 + z) / 2.0).max(0.0).sqrt(), ((1.0 - z) / 2.0).max(0.0).sqrt());
            let phi = y.atan2(x);
            [[up, 0.0], [down * phi.cos(), down * phi.sin()]]
        })
        .collect();
    (0..1usize << bloch.len())
        .map(|s| {
            spins.iter().enumerate().fold([1.0, 0.0], |p, (j, spin)| {
                let q = spin[(s >> j) & 1];
                [p[0] * q[0] - p[1] * q[1], p[0] * q[1] + p[1] * q[0]]
            })
        })
        .collect()
}

/// Bloch vectors of the noiseless scar state at time t (exact reference 1): every spin along
/// (−cos ht, −sin ht, 0); with `flip = Some(k)`, spin k reversed in the xy plane (σᶻ_k applied).
pub fn reference_bloch(l: usize, h: f64, t: f64, flip: Option<usize>) -> Vec<[f64; 3]> {
    let (sin, cos) = (h * t).sin_cos();
    (0..l).map(|j| if flip == Some(j) { [cos, sin, 0.0] } else { [-cos, -sin, 0.0] }).collect()
}

/// Bloch vectors of the noiseless coherent state at time t: every spin along (sin θ cos(φ + ht), sin θ sin(φ + ht),
/// cos θ) (θ = π/2, φ = π: reference 1); with `kick = Some((k, α))`, σ^α applied to spin k, i.e. its Bloch vector
/// rotated by π about axis α (0, 1, 2 = x, y, z).
pub fn coherent_reference(l: usize, h: f64, t: f64, theta: f64, phi: f64, kick: Option<(usize, usize)>) -> Vec<[f64; 3]> {
    let (st, ct) = theta.sin_cos();
    let (sp, cp) = (phi + h * t).sin_cos();
    let n = [st * cp, st * sp, ct];
    (0..l)
        .map(|j| match kick {
            Some((k, axis)) if k == j => match axis {
                0 => [n[0], -n[1], -n[2]],
                1 => [-n[0], n[1], -n[2]],
                _ => [-n[0], -n[1], n[2]],
            },
            _ => n,
        })
        .collect()
}

/// c_j = (⟨σˣ_j⟩ + i⟨σʸ_j⟩) / (sin θ e^{i(φ + ht)}), the transverse Bloch vector relative to that of the noiseless
/// coherent state at time t (1 on that state). θ = π/2, φ = π gives [`coherences`].
pub fn coherences_theta(site: &[Vec<f64>; 3], h: f64, t: f64, theta: f64, phi: f64) -> Vec<Amp> {
    let (sin, cos) = (phi + h * t).sin_cos();
    let st = theta.sin();
    site[0]
        .iter()
        .zip(&site[1])
        .map(|(&x, &y)| [(x * cos + y * sin) / st, (y * cos - x * sin) / st])
        .collect()
}

/// c_j = (⟨σˣ_j⟩ + i⟨σʸ_j⟩) / (reference-1 value at time t) = −(⟨σˣ_j⟩ + i⟨σʸ_j⟩) e^{−iht}, for every site,
/// from the per-site magnetization `site` (as returned by `per_site`). 1 on the noiseless scar state.
pub fn coherences(site: &[Vec<f64>; 3], h: f64, t: f64) -> Vec<Amp> {
    let (sin, cos) = (h * t).sin_cos();
    site[0].iter().zip(&site[1]).map(|(&x, &y)| [-(x * cos + y * sin), -(y * cos - x * sin)]).collect()
}

/// Jump-unravelling trajectory (see the module docs). Starting from the scar state |−⟩^⊗L
/// (`analytic = true`), the state before the first kick is the reference-1 product state, written down at
/// the time of the first kick instead of being evolved; until then no state vector is allocated.
pub struct JumpTrajectory<'a> {
    ham: &'a Hamiltonian,
    h: f64,
    /// Rate of each site's kicks, γ; total rate γL.
    gamma: f64,
    /// The state, once it is no longer the reference-1 product state (None before the first kick).
    traj: Option<Trajectory<'a>>,
    /// Current time.
    t: f64,
    next_kick: f64,
    pub kicks: usize,
    rng: Rng,
}

impl<'a> JumpTrajectory<'a> {
    /// Starts in the product state `bloch` at t = 0. `analytic`: the start is the scar state |−⟩^⊗L, whose
    /// evolution under H is known in closed form (reference 1), so it is not evolved before the first kick.
    pub fn new(ham: &'a Hamiltonian, h: f64, gamma: f64, bloch: &[[f64; 3]], analytic: bool, seed: u64) -> Self {
        let mut rng = Rng::new(seed);
        let next_kick = Self::waiting_time(&mut rng, gamma, ham.l);
        let traj = (!analytic).then(|| Trajectory::product(ham, bloch, seed));
        JumpTrajectory { ham, h, gamma, traj, t: 0.0, next_kick, kicks: 0, rng }
    }

    fn waiting_time(rng: &mut Rng, gamma: f64, l: usize) -> f64 {
        if gamma > 0.0 {
            -rng.uniform().ln() / (gamma * l as f64)
        } else {
            f64::INFINITY
        }
    }

    /// Advance to time t_new ≥ t: unitary evolution between the kicks that fall in (t, t_new].
    pub fn advance_to(&mut self, t_new: f64) {
        while self.next_kick <= t_new {
            let tk = self.next_kick;
            match &mut self.traj {
                Some(traj) => traj.unitary(tk - self.t),
                None => {
                    let bloch = reference_bloch(self.ham.l, self.h, tk, None);
                    self.traj = Some(Trajectory::product(self.ham, &bloch, 0));
                }
            }
            let l = self.ham.l;
            let site = ((self.rng.uniform() * l as f64) as usize).min(l - 1);
            self.traj.as_mut().unwrap().flip(site);
            self.kicks += 1;
            self.t = tk;
            self.next_kick = tk + Self::waiting_time(&mut self.rng, self.gamma, l);
        }
        if let Some(traj) = &mut self.traj {
            if t_new > self.t {
                traj.unitary(t_new - self.t);
            }
        }
        self.t = t_new;
    }

    /// The state vector, or None before the first kick (the analytic product state, which has no entanglement).
    pub fn state(&self) -> Option<&[Amp]> {
        self.traj.as_ref().map(|t| t.psi.as_slice())
    }

    /// ⟨ψ|σ^α_j|ψ⟩ for α = x, y, z and every site j, at the current time.
    pub fn per_site(&self) -> [Vec<f64>; 3] {
        match &self.traj {
            Some(traj) => traj.per_site(),
            None => {
                let (sin, cos) = (self.h * self.t).sin_cos();
                let l = self.ham.l;
                [vec![-cos; l], vec![-sin; l], vec![0.0; l]]
            }
        }
    }
}

/// xoshiro256++ with Gaussian samples (Box-Muller).
pub struct Rng {
    s: [u64; 4],
    spare: Option<f64>,
}

impl Rng {
    pub fn new(seed: u64) -> Self {
        // splitmix64 expands the seed into the state
        let mut z = seed;
        let s = [0; 4].map(|_| {
            z = z.wrapping_add(0x9e3779b97f4a7c15);
            let mut x = z;
            x = (x ^ (x >> 30)).wrapping_mul(0xbf58476d1ce4e5b9);
            x = (x ^ (x >> 27)).wrapping_mul(0x94d049bb133111eb);
            x ^ (x >> 31)
        });
        Rng { s, spare: None }
    }

    fn next_u64(&mut self) -> u64 {
        let s = &mut self.s;
        let result = s[0].wrapping_add(s[3]).rotate_left(23).wrapping_add(s[0]);
        let t = s[1] << 17;
        s[2] ^= s[0];
        s[3] ^= s[1];
        s[1] ^= s[2];
        s[0] ^= s[3];
        s[2] ^= t;
        s[3] = s[3].rotate_left(45);
        result
    }

    /// Uniform in (0, 1].
    pub fn uniform(&mut self) -> f64 {
        ((self.next_u64() >> 11) as f64 + 1.0) / (1u64 << 53) as f64
    }

    /// Standard normal.
    pub fn gaussian(&mut self) -> f64 {
        if let Some(x) = self.spare.take() {
            return x;
        }
        let r = (-2.0 * self.uniform().ln()).sqrt();
        let (sin, cos) = (2.0 * std::f64::consts::PI * self.uniform()).sin_cos();
        self.spare = Some(r * sin);
        r * cos
    }
}

/// Uniformly random unit vector (normalized Gaussian vector).
pub fn random_direction(rng: &mut Rng) -> [f64; 3] {
    let v = [0; 3].map(|_| rng.gaussian());
    let norm = v.iter().map(|x| x * x).sum::<f64>().sqrt();
    v.map(|x| x / norm)
}
